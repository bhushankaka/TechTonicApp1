package com.manoj;

import java.awt.Component;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

/**
 * Servlet implementation class HomeController
 */
public class HomeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HomeController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();

		String user = request.getParameter("selectuser");
		
		Employee e1 = new Employee(request.getParameter("email"),request.getParameter("namesignup"),request.getParameter("passsignup"));
		
		try {
			//System.out.println(email+" "+uname+" "+pass);
			
			ConnectToDB c = new ConnectToDB();
			Connection con = c.getConnection();
			
			
			Statement stmt = con.createStatement();
			
			
			ResultSet rs = stmt.executeQuery("select email from login where email='"+e1.email+"'");
			
			if(rs.next())
			{
				System.out.println("User Email Already Exists");
			
				 //JOptionPane.showMessageDialog(null, "Done......!", "User Email Already Exists", JOptionPane.INFORMATION_MESSAGE);
				RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
				rd.forward(request, response);
				
				
			}
			else
			{
				stmt.executeUpdate("insert into login values('"+e1.email+"','"+e1.uname+"','"+e1.pass+"','"+user+"')");
				System.out.println("Successfully Registered New User.");
			 
				
				RequestDispatcher rd = request.getRequestDispatcher("Home.jsp");
				rd.forward(request, response);
			}
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

}
